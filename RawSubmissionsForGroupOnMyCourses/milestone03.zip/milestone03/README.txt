Milestone 03 - Deployment Strategy

1). To run the main application double click on milestone3.jar 
2). To run the test please double click on the milestone3test.jar and enter your commands into the left side of the gui

Feel free to take a look at our entire project on GitHub with the link below. 

Github Link: 
https://github.com/TomoKulusic/appDevelopment/tree/master/workingExample




