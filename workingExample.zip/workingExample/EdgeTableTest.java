import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class EdgeTableTest {
   EdgeTable testObj;
 

   @Before
   public void setUp() throws Exception {
      testObj = new EdgeTable("1|student");
      runner();
   }
   public void runner() {
      testGetNum();
      testGetName();
   
   
   }
   @Test
   public void testGetNum() {
      assertEquals("testGetNum was intialized to 1 so it should be 1",1,testObj.getNumFigure());
   }

   @Test
   public void testGetName() {
      assertEquals("testGetName was intialized to student","student",testObj.getName());
   }
}