import static org.junit.Assert.*;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Test;
/**
nov 10 2017


*/

public class EdgeTableTest {

   String command;

   EdgeTable testObj;
   
   public EdgeTableTest(String _command){
   
      System.out.println("The constructor was called");
      command = _command;
      try{
         setUp();
      }
      catch(Exception e){
      
         System.out.println("oh shit");
      }
   
   
   }
   

 

   @Before
   public void setUp() throws Exception {
           testObj = new EdgeTable(command);
      runner();
   }
   
   public void runner() {
        
      testGetNum();
      testGetName();
     
   }
   @Test
   public void testGetNum() {
      System.out.println("testGetNum was intialized to 1 so it should be 1");
      assertEquals(1,testObj.getNumFigure());
         }

   @Test
   public void testGetName() {
     System.out.println("testGetName was intialized to student , should be student");
      assertEquals("student",testObj.getName());
         }
}