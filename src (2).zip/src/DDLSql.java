import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.assertEquals;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;


public class DDLSql {
   String output = "CREATE DATABASE MySQLDB; USE MySQLDB; CREATE TABLE STUDENT ( StudentSSN VARCHAR(1), StudentName VARCHAR(1)); CREATE TABLE FACULTY ( FacultyName VARCHAR(1), FacSSN VARCHAR(1)); CREATE TABLE COURSES ( Grade VARCHAR(1), Number VARCHAR(1));";
   

   String input = "MySQLDB";
   int numTable = 3;
   
   int numFields = 7;
   
 	
   //calls edge table class
 CreateDDLMySQL ddl = new CreateDDLMySQL();
   
   @Test  
	public void testPrintMessage(){
		System.out.println("Inside getSqlString()");
      
      System.out.println("Sending string to Sql");
      
      //does edge table equal name?
		assertEquals(output, ddl.getSQLString());
      
      //To show the name   
      System.out.println(ddl.getSQLString());
           
	}


   
   
}