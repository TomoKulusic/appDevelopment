import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.assertEquals;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

public class TestEdgeTable {
	String name = " 1 | student";
	
   EdgeTable edgeTable = new EdgeTable(name);
   
   
}
