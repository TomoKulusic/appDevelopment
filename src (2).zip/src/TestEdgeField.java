import org.junit.Test;
import org.junit.Ignore;
import static org.junit.Assert.assertEquals;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;

public class TestEdgeField {
	String input = " 3|Grade";
   String name = "Grade";
   int num = 3;
	
   EdgeField edgeField = new EdgeField(input);
   
   @Test  
	public void testPrintMessage(){
		System.out.println("Inside testPrintMessage()");
      
      System.out.println("Sending string to EdgeField");
      
		assertEquals(name, edgeField.getName());
          
      System.out.println(edgeField.getName());
      
	}
   
   /*public void testOuput() {
   string output = ""
   
   }*/
   
    @Test  
	public void testPrintMessage2(){
		System.out.println("Inside testPrintMessage2()");
      
      System.out.println("Sending num to EdgeField");
      
		
      assertEquals(num, edgeField.getNumFigure());
      
      System.out.println(edgeField.getNumFigure());
      
	}


   
   
}
