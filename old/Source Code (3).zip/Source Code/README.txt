

HOW TO SET UP THE JUNIT ENVIRONMENT IN JGRASP


Open SETTINGS

OPEN PATH/CLASSPATH

OPEN WOKSPACE

IN CLASSPATH TAB, CLICK NEW

Select the junit-4. 12.jar && Select the hamcrest-core-1.3.jar


CLICK APPLY

CLICK  OK


RUN THE FILES CALLED TestRunnerEdgeField.JAVA , TestRunnerEdgeField.JAVA, TestRunnerSql.java , TestRunnerEdgeConnector.java
