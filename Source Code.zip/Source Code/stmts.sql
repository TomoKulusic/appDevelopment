drop database if exists blah;
create database blah;
use blah;
create table foo(

bar int,
bas varchar(5),
qux varchar(255)



);